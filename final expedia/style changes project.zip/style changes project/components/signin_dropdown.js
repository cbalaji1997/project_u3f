let homePageSiginDropdown = () =>
{
    return `
    <h3>Members can access discounts and special features</h3>
        <button id="sigin_button"><a href="sigin.html">Sign in</a> </button>
        <button id="create_account" > <a href="create account.html">Create a Free account</a> </button>
        <p>List of Favourites</p>
        <p>Expedia Rewards</p>
        <hr>
        <p>Feedback</p>`;
}
export {homePageSiginDropdown}